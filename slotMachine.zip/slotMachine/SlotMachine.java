import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 * Simulador de una maquina tragamonedas.
 * Los simbolos se identifican mediante colores del estandar CSS y son
 * compartidos por todas las ruedas: cada rueda solo guarda la posicion
 * del simbolo que esta mostrando.
 *
 * @author (Santiago Aldana, Juan Alvarez)
 * @version (23/08/26)
 */
public class SlotMachine {

    private ArrayList<String> symbols;
    private ArrayList<Wheel> wheels;
    private Rectangle body;
    private Rectangle light;
    private boolean isVisible;
    private boolean ok;

    private static final int FIRST_X = 100;
    private static final int WHEEL_Y = 120;
    private static final int SPACING = 70;
    private static final int INITIAL_SIZE = 3;
    private static final int LIGHT_X = 105;
    private static final int LIGHT_Y = 197;
    private static final String BODY_COLOR = "silver";
    private static final String LIGHT_OFF = "gray";
    private static final String LIGHT_ON = "gold";

    /**
     * Crea una maquina tragamonedas con 3 ruedas y 3 simbolos.
     */
    public SlotMachine() {
        symbols = new ArrayList<String>();
        wheels = new ArrayList<Wheel>();
        isVisible = false;
        ok = true;

        body = new Rectangle();
        body.changeSize(130, 250);
        body.changeColor(BODY_COLOR);
        body.moveHorizontal(70 - 70);
        body.moveVertical(90 - 15);

        light = new Rectangle();
        light.changeSize(16, 180);
        light.changeColor(LIGHT_OFF);
        light.moveHorizontal(LIGHT_X - 70);
        light.moveVertical(LIGHT_Y - 15);

        symbols.add("red");
        symbols.add("gold");
        symbols.add("blue");

        for (int i = 0; i < INITIAL_SIZE; i++) {
            Wheel w = new Wheel(FIRST_X + i * SPACING, WHEEL_Y);
            w.setPosition(i);
            wheels.add(w);
        }
    }

    /**
     * Hace visible el simulador.
     */
    public void makeVisible() {
        isVisible = true;
        body.makeVisible();
        light.makeVisible();
        for (int i = 0; i < wheels.size(); i++) {
            Wheel w = wheels.get(i);
            w.makeVisible();
            refresh(w);
        }
        updateLook();
        ok = true;
    }

    /**
     * Hace invisible el simulador.
     */
    public void makeInvisible() {
        for (int i = 0; i < wheels.size(); i++) {
            wheels.get(i).makeInvisible();
        }
        light.makeInvisible();
        body.makeInvisible();
        isVisible = false;
        ok = true;
    }

    /**
     * Adiciona una rueda en la posicion indicada.
     * @param pos posicion donde se inserta la rueda, empezando en 1
     */
    public void addWheel(int pos) {
        int index = insertIndex(pos, wheels.size());
        Wheel w = new Wheel(0, WHEEL_Y);
        wheels.add(index, w);
        relocate();
        if (isVisible) {
            w.makeVisible();
            refresh(w);
        }
        updateLook();
        ok = true;
    }

    /**
     * Elimina la rueda de la posicion indicada.
     * @param pos posicion de la rueda a eliminar, empezando en 1
     */
    public void delWheel(int pos) {
        if (wheels.size() == 0) {
            error("No hay ruedas para eliminar.");
            return;
        }
        int index = wheelIndex(pos);
        Wheel w = wheels.get(index);
        w.makeInvisible();
        wheels.remove(index);
        relocate();
        updateLook();
        ok = true;
    }

    /**
     * Adiciona un simbolo en la posicion indicada.
     * @param pos posicion donde se inserta el simbolo, empezando en 1
     * @param color nombre CSS del color del nuevo simbolo
     */
    public void addSymbol(int pos, String color) {
        if (!CSSColor.isValid(color)) {
            error("El color " + color + " no es un color CSS valido.");
            return;
        }
        if (symbols.contains(color)) {
            error("El simbolo " + color + " ya existe en la maquina.");
            return;
        }
        int index = insertIndex(pos, symbols.size());
        symbols.add(index, color);
        for (int i = 0; i < wheels.size(); i++) {
            Wheel w = wheels.get(i);
            if (w.getPosition() >= index) {
                w.setPosition(w.getPosition() + 1);
            }
            refresh(w);
        }
        updateLook();
        ok = true;
    }

    /**
     * Elimina el simbolo del color indicado.
     * @param symbol nombre CSS del color a eliminar
     */
    public void delSymbol(String symbol) {
        int index = symbols.indexOf(symbol);
        if (index < 0) {
            error("El simbolo " + symbol + " no existe en la maquina.");
            return;
        }
        symbols.remove(index);
        for (int i = 0; i < wheels.size(); i++) {
            Wheel w = wheels.get(i);
            int pos = w.getPosition();
            if (pos >= index) {
                w.setPosition(pos - 1);
            }
            if (w.getPosition() < 0) {
                w.setPosition(0);
            }
            refresh(w);
        }
        updateLook();
        ok = true;
    }

    /**
     * Gira una rueda una posicion.
     * @param wheel numero de la rueda, empezando en 1
     */
    public void spin(int wheel) {
        if (symbols.size() == 0 || wheels.size() == 0) {
            error("La maquina no tiene ruedas o simbolos.");
            return;
        }
        int index = wheelIndex(wheel);
        Wheel w = wheels.get(index);
        int actual = w.getPosition();
        int nueva = (actual + 1) % symbols.size();
        w.setPosition(nueva);
        refresh(w);
        updateLook();
        ok = true;
    }

    /**
     * Gira todas las ruedas de la maquina.
     */
    public void spin() {
        if (wheels.size() == 0 || symbols.size() == 0) {
            error("La maquina no tiene ruedas o simbolos.");
            return;
        }
        for (int i = 1; i <= wheels.size(); i++) {
            spin(i);
        }
    }

    /**
     * Ubica un simbolo en la ventana de una rueda.
     * @param wheel numero de la rueda, empezando en 1
     * @param symbol color del simbolo que debe quedar visible
     */
    public void placeSymbol(int wheel, String symbol) {
        int pos = symbols.indexOf(symbol);
        if (pos < 0 || wheels.size() == 0) {
            error("No se puede ubicar el simbolo " + symbol + ".");
            return;
        }
        int index = wheelIndex(wheel);
        Wheel w = wheels.get(index);
        w.setPosition(pos);
        refresh(w);
        updateLook();
        ok = true;
    }

    /**
     * Retorna los colores de los simbolos de la maquina, en orden.
     * @return arreglo con los colores de los simbolos
     */
    public String[] symbols() {
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i);
        }
        ok = true;
        return result;
    }

    /**
     * Retorna los colores visibles en las ruedas, de izquierda a derecha.
     * @return arreglo con la configuracion actual
     */
    public String[] configuration() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = colorOf(wheels.get(i));
        }
        ok = true;
        return result;
    }

    /**
     * Retorna la cantidad de simbolos distintos visibles en la maquina.
     * @return numero de colores diferentes en la configuracion actual
     */
    public int distinctSymbols() {
        ArrayList<String> found = new ArrayList<String>();
        for (int i = 0; i < wheels.size(); i++) {
            String color = colorOf(wheels.get(i));
            if (!found.contains(color)) {
                found.add(color);
            }
        }
        ok = true;
        return found.size();
    }

    /**
     * Indica si la maquina esta en una configuracion ganadora.
     * @return true si todas las ruedas muestran el mismo simbolo
     */
    public boolean isJackpot() {
        return wheels.size() > 0 && distinctSymbols() == 1;
    }

    /**
     * Indica si la ultima operacion solicitada se pudo realizar.
     * @return true si la ultima operacion fue exitosa
     */
    public boolean ok() {
        return ok;
    }

    /**
     * Termina el simulador.
     */
    public void exit() {
        makeInvisible();
        System.exit(0);
    }

    /**
     * Enciende la barra indicadora si la maquina esta en estado ganador.
     * La barra no se solapa con las ruedas, asi que repintarla nunca las tapa.
     */
    private void updateLook() {
        if (!isVisible) {
            return;
        }
        if (isJackpot()) {
            light.changeColor(LIGHT_ON);
        } else {
            light.changeColor(LIGHT_OFF);
        }
    }

    /**
     * Registra que la ultima operacion fallo y avisa al usuario.
     * Solo muestra el mensaje si el simulador esta visible.
     * @param message descripcion del problema
     */
    private void error(String message) {
        ok = false;
        if (isVisible) {
            JOptionPane.showMessageDialog(null, message);
        }
    }

    /**
     * Retorna el color del simbolo que muestra una rueda.
     * @param w rueda consultada
     * @return nombre del color, o null si no hay simbolos
     */
    private String colorOf(Wheel w) {
        if (symbols.size() == 0) {
            return null;
        }
        return symbols.get(w.getPosition());
    }

    /**
     * Actualiza en pantalla el simbolo que muestra una rueda.
     * @param w rueda que se debe repintar
     */
    private void refresh(Wheel w) {
        if (isVisible && symbols.size() > 0) {
            w.show(colorOf(w));
        }
    }

    /**
     * Reubica todas las ruedas en pantalla segun su orden actual.
     */
    private void relocate() {
        for (int i = 0; i < wheels.size(); i++) {
            wheels.get(i).moveTo(FIRST_X + i * SPACING, WHEEL_Y);
        }
    }

    /**
     * Convierte un numero de rueda (base 1) en indice de la lista (base 0),
     * recortando al rango valido.
     * @param wheel numero de rueda solicitado
     * @return indice valido dentro de wheels
     */
    private int wheelIndex(int wheel) {
        if (wheel < 1) {
            return 0;
        }
        if (wheel > wheels.size()) {
            return wheels.size() - 1;
        }
        return wheel - 1;
    }

    /**
     * Convierte una posicion de insercion (base 1) en indice de lista,
     * recortando al rango valido.
     * @param pos posicion solicitada
     * @param size tamano actual de la lista
     * @return indice valido para insertar
     */
    private int insertIndex(int pos, int size) {
        if (pos < 1) {
            return 0;
        }
        if (pos > size) {
            return size;
        }
        return pos - 1;
    }
}
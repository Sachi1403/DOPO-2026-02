/**
 * Representa una rueda de la maquina tragamonedas.
 * Una rueda solo sabe que posicion de la lista de simbolos esta mostrando;
 * la lista de simbolos vive en SlotMachine.
 *
 * @author (sus nombres)
 * @version (fecha)
 */
public class Wheel {

    private int position;
    private int x;
    private int y;
    private Rectangle frame;
    private Rectangle symbolBox;
    private boolean isVisible;

    /**
     * Crea una rueda ubicada en la posicion (x, y) de la pantalla.
     * @param x coordenada horizontal
     * @param y coordenada vertical
     */
    public Wheel(int x, int y) {
        position = 0;
        isVisible = false;
        this.x = x;
        this.y = y;

        frame = new Rectangle();
        frame.changeSize(70, 50);
        frame.changeColor("black");
        frame.moveHorizontal(x - 70);
        frame.moveVertical(y - 15);

        symbolBox = new Rectangle();
        symbolBox.changeSize(60, 40);
        symbolBox.changeColor("white");
        symbolBox.moveHorizontal(x - 70 + 5);
        symbolBox.moveVertical(y - 15 + 5);
    }

    /**
     * Hace visible la rueda.
     */
    public void makeVisible() {
        isVisible = true;
        frame.makeVisible();
        symbolBox.makeVisible();
    }

    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible() {
        symbolBox.makeInvisible();
        frame.makeInvisible();
        isVisible = false;
    }

    /**
     * Mueve la rueda a una nueva ubicacion en pantalla.
     * @param newX nueva coordenada horizontal
     * @param newY nueva coordenada vertical
     */
    public void moveTo(int newX, int newY) {
        frame.moveHorizontal(newX - x);
        frame.moveVertical(newY - y);
        symbolBox.moveHorizontal(newX - x);
        symbolBox.moveVertical(newY - y);
        x = newX;
        y = newY;
    }

    /**
     * Cambia el color que se muestra en la ventana de la rueda.
     * @param color nombre CSS del color del simbolo visible
     */
    public void show(String color) {
        symbolBox.changeColor(color);
    }

    /**
     * Retorna el indice del simbolo que la rueda esta mostrando.
     * @return la posicion actual
     */
    public int getPosition() {
        return position;
    }

    /**
     * Cambia el indice del simbolo que la rueda muestra.
     * @param position nuevo indice
     */
    public void setPosition(int position) {
        this.position = position;
    }
}
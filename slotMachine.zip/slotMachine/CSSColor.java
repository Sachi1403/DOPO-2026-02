import java.awt.Color;

/**
 * Traduce nombres de colores del estandar CSS a objetos Color.
 * @author (sus nombres)
 * @version (fecha)
 */
public class CSSColor {
    private static String[] names = {
        "black", "white", "red", "lime", "blue", "yellow",
        "cyan", "magenta", "gray", "maroon", "green", "purple",
        "teal", "navy", "orange", "pink", "gold", "brown",
        "coral", "indigo", "salmon", "turquoise", "violet", "khaki", "silver"
    };

    private static Color[] colors = {
        new Color(0, 0, 0),       new Color(255, 255, 255),
        new Color(255, 0, 0),     new Color(0, 255, 0),
        new Color(0, 0, 255),     new Color(255, 255, 0),
        new Color(0, 255, 255),   new Color(255, 0, 255),
        new Color(128, 128, 128), new Color(128, 0, 0),
        new Color(0, 128, 0),     new Color(128, 0, 128),
        new Color(0, 128, 128),   new Color(0, 0, 128),
        new Color(255, 165, 0),   new Color(255, 192, 203),
        new Color(255, 215, 0),   new Color(165, 42, 42),
        new Color(255, 127, 80),  new Color(75, 0, 130),
        new Color(250, 128, 114), new Color(64, 224, 208),
        new Color(238, 130, 238), new Color(240, 230, 140),
        new Color(192, 192, 192)
    };
    
    /**
     * Retorna el Color que corresponde a un nombre CSS.
     * @param name nombre del color
     * @return el Color, o null si el nombre no existe
     */
    public static Color get(String name) {
        for (int i = 0; i < names.length; i++) {
            if (names[i].equals(name)) {
                return colors[i];
            }
        }
        return null;
    }

    /**
     * Indica si el nombre corresponde a un color CSS soportado.
     * @param name nombre del color
     * @return true si el color existe
     */
    public static boolean isValid(String name) {
        return get(name) != null;
    }

    /**
     * Retorna todos los nombres de colores disponibles.
     * @return arreglo con los nombres CSS soportados
     */
    public static String[] availableColors() {
        return names;
    }
}
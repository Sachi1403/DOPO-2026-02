import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SlotMachineC2Test {

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Verifica que al bloquear una rueda existente con lock(int), 
     * la operación sea exitosa y el indicador ok() retorne true.
     */
    @Test
    public void accordingAgAjShouldLockWheelSuccessfully() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addWheel(1);
        slotMachine.lock(1);
        assertTrue(slotMachine.ok());
    }
    
    /**
     * Verifica que al desbloquear una rueda previamente bloqueada 
     * mediante unlock(int), la máquina procese la instrucción correctamente.
     */
    @Test
    public void accordingAgAjShouldUnlockWheelSuccessfully() {
        SlotMachine slotMachine = new SlotMachine();
        slotMachine.addWheel(1);
        slotMachine.lock(1);
        slotMachine.unlock(1);
        assertTrue(slotMachine.ok());
    }
}
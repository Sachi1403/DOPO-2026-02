import javax.swing.JOptionPane;
import java.util.ArrayList;

public class SlotMachine {
    private boolean lastOperationOk;
    private boolean isVisible;
    private ArrayList<Wheel> wheels; 
    private Rectangle fondo; // Nuestro nuevo fondo visual

    // Método privado para manejar los mensajes de error visuales
    private void reportarError(String mensaje) {
        lastOperationOk = false;
        if (isVisible) {
            JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public SlotMachine() {
        lastOperationOk = true;
        isVisible = false;
        wheels = new ArrayList<>(); 
        
        // Configuramos el fondo visual
        fondo = new Rectangle();
        fondo.changeSize(200, 300); // Hacemos un rectángulo grande
        fondo.changeColor("blue"); // Color normal de la máquina
    }
    
    public boolean ok() {
        return lastOperationOk;
    }
    
    public void addWheel(int pos) {
        // 1. Regla del diseño: si es menor a 1, lo forzamos a ser 1
        if (pos < 1) {
            pos = 1;
        }
        
        // 2. Regla del diseño: si excede el tamaño, lo ponemos al final.
        // Como vamos a agregar uno nuevo, el límite máximo permitido es el tamaño actual + 1.
        if (pos > wheels.size() + 1) {
            pos = wheels.size() + 1;
        }
        
        // 3. Traducimos la posición del usuario (ej. 1) al índice de Java (ej. 0)
        int indice = pos - 1;
        
        // 4. Creamos la nueva rueda y la agregamos a la lista en el índice calculado
        Wheel nuevaRueda = new Wheel();
        wheels.add(indice, nuevaRueda);
        
        // 5. Memorizamos que la operación fue exitosa
        lastOperationOk = true;
    }
    
    public void delWheel(int pos) {
        // 0. Si la lista está vacía, no hay nada que borrar. La operación falla.
        if (wheels.isEmpty()) {
            reportarError("No se puede eliminar: la máquina no tiene ruedas.");
            return; 
        }

        // 1. Regla de diseño: si es menor a 1, usamos la posición 1
        if (pos < 1) {
            pos = 1;
        }
        
        // 2. Regla de diseño: si es mayor al número máximo de elementos, usamos el máximo
        if (pos > wheels.size()) {
            pos = wheels.size();
        }
        
        // 3. Traducimos la posición del usuario al índice de Java
        int indiceJava = pos - 1;
        
        // 4. Eliminamos la rueda de la lista
        wheels.remove(indiceJava);
        
        // 5. Memorizamos que la operación fue exitosa
        lastOperationOk = true;
    }
    
    public void addSymbol(int pos, String color) {
        // Si no hay ruedas, la operación falla
        if (wheels.isEmpty()) {
            reportarError("No se puede modificar símbolos: la máquina no tiene ruedas.");
            return;
        }

        // Le ordenamos a cada 'rueda' de nuestra lista que agregue el símbolo
        for (Wheel rueda : wheels) {
            rueda.addSymbol(pos, color);
        }
        
        lastOperationOk = true;
    }

    public void delSymbol(String symbol) {
        // Si no hay ruedas, la operación falla
        if (wheels.isEmpty()) {
            reportarError("No se puede modificar símbolos: la máquina no tiene ruedas.");
            return;
        }

        // Le ordenamos a cada 'rueda' que borre el símbolo con ese color
        for (Wheel rueda : wheels) {
            rueda.delSymbol(symbol);
        }
        
        lastOperationOk = true;
    }
    
    // Gira una rueda específica
    public void spin(int wheel) {
        // Validamos si la rueda que pide el usuario realmente existe
        if (wheel < 1 || wheel > wheels.size()) {
            reportarError("La rueda solicitada no existe.");
            return;
        }
        
        // Traducimos a índice de Java y le damos la orden a esa rueda específica
        int indiceJava = wheel - 1;
        wheels.get(indiceJava).spin();
        revisarPremioVisual();
        lastOperationOk = true;
        
        
    }

    // Gira TODAS las ruedas de la máquina
    public void spin(int wheel, int steps) {
        // 1. Validamos que el número de rueda sea correcto
        if (wheel > 0 && wheel <= wheels.size()) {
            Wheel ruedaSeleccionada = wheels.get(wheel - 1);
            
            // 2. Si no está bloqueada, giramos paso a paso
            if (!ruedaSeleccionada.isLocked()) {
                for (int i = 0; i < steps; i++) {
                    ruedaSeleccionada.spin();
                }
            }
            
            // 3. Revisamos si con este movimiento se logró el jackpot
            revisarPremioVisual();
            lastOperationOk = true;
        } else {
            lastOperationOk = false;
        }
    }
    
    
    // Coloca un símbolo específico al frente de una rueda específica
    public void placeSymbol(int wheel, String symbol) {
        // Validamos si la rueda que pide el usuario realmente existe
        if (wheel < 1 || wheel > wheels.size()) {
            reportarError("La rueda solicitada no existe.");
            return;
        }
        
        wheels.get(wheel - 1).placeSymbol(symbol);
        revisarPremioVisual();
        lastOperationOk = true;
    }

    // Retorna los símbolos visibles de todas las ruedas ordenados de izquierda a derecha
    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            config[i] = wheels.get(i).getVisibleSymbol();
        }
        return config;
    }

    // Retorna cuántos símbolos distintos hay en la configuración actual
    public int distinctSymbols() {
        String[] config = configuration();
        ArrayList<String> unicos = new ArrayList<>();
        
        for (String color : config) {
            if (!unicos.contains(color)) {
                unicos.add(color);
            }
        }
        return unicos.size();
    }
    
    // Requisito: Consultar si la configuración es la ganadora
    public boolean isjackpot() {
        // Si no hay ruedas, no se puede ganar
        if (wheels.isEmpty()) {
            return false;
        }
        
        
        // Es jackpot si todos los símbolos visibles son idénticos (es decir, solo hay 1 tipo de símbolo)
        return distinctSymbols() == 1;
    }

    // Requisito: Consultar todos los símbolos de la rueda
    public String[] symbols() {
        if (wheels.isEmpty()) {
            return new String[0]; // Retorna un arreglo vacío si no hay ruedas
        }
        // Retorna los colores de los símbolos en el orden que están en la primera rueda
        return wheels.get(0).getSymbols();
    }
    
    // Requisito: Hacer visible la máquina
    public void makeVisible() {
        isVisible = true;
        fondo.makeVisible(); 
        
        int distanciaX = 80; // La primera rueda empezará un poco separada del borde izquierdo
        
        for (Wheel rueda : wheels) {
            rueda.ajustarPosicionHorizontal(distanciaX); // Acomodamos la rueda
            rueda.makeVisible(); // La mostramos
            
            distanciaX = distanciaX + 60; // Sumamos 60 píxeles para que la SIGUIENTE rueda quede más a la derecha
        }
        
        lastOperationOk = true;
    }

    public void makeInvisible() {
       isVisible = false;
        fondo.makeInvisible(); // Ocultamos el fondo
        for (Wheel rueda : wheels) {
            rueda.makeInvisible();
        }
        lastOperationOk = true;
    }
    
    public void swap(int wheel1, int wheel2) {
        // 1. Verificamos que las posiciones sean válidas para evitar errores
        if (wheel1 > 0 && wheel1 <= wheels.size() && wheel2 > 0 && wheel2 <= wheels.size()) {
            
            // 2. Convertimos las posiciones del usuario a índices de Java (restamos 1)
            int indice1 = wheel1 - 1;
            int indice2 = wheel2 - 1;
            
            // 3. El intercambio: usamos una variable temporal para guardar la primera rueda
            Wheel temporal = wheels.get(indice1);
            
            // 4. Ponemos la segunda rueda en el lugar de la primera
            wheels.set(indice1, wheels.get(indice2));
            
            // 5. Ponemos la rueda temporal en el lugar de la segunda
            wheels.set(indice2, temporal);
            
            // Todo salió bien
            lastOperationOk = true;
            
        } else {
            // Si nos dan posiciones que no existen, la operación falla
            lastOperationOk = false;
        }
    }
    
    public void lock(int wheel) {
        // Validamos que el número de rueda exista
        if (wheel > 0 && wheel <= wheels.size()) {
            int indice = wheel - 1;
            wheels.get(indice).lock(); // Le damos la orden a esa rueda específica
            lastOperationOk = true;
        } else {
            lastOperationOk = false;
        }
    }

    public void unlock(int wheel) {
        // Validamos que el número de rueda exista
        if (wheel > 0 && wheel <= wheels.size()) {
            int indice = wheel - 1;
            wheels.get(indice).unlock(); // Le damos la orden a esa rueda específica
            lastOperationOk = true;
        } else {
            lastOperationOk = false;
        }
    }
    
    // Método privado para actualizar visualmente la máquina si hay premio
    private void revisarPremioVisual() {
        if (isjackpot()) {
            fondo.changeColor("magenta"); // Color ganador (¡cambia a algo llamativo!)
        } else {
            fondo.changeColor("blue"); // Vuelve a su color normal si ya no es ganador
        }
    }

    // Requisito: Terminar el simulador
    public void exit() {
        System.exit(0); // Comando estándar de Java para cerrar la aplicación
    }
    // ... Iremos agregando los demás métodos (addWheel, etc.) aquí adentro
}
public class Symbol {
    // 1. Los atributos privados que definimos en Astah
    private String color;
    private Circle shape; // Usamos Circle del paquete shapes como base visual

    // 2. El constructor: se ejecuta cuando creamos un nuevo Símbolo
    public Symbol(String color) {
        this.color = color; // Guardamos el color que nos pasen (ej. "red")
        
        // Inicializamos la parte visual
        shape = new Circle(); 
        shape.changeColor(color); // Pintamos el círculo con el color recibido
    }

    // 3. El método para consultar el color
    public String getColor() {
        return color;
    }
    
    public void makeVisible() {
        shape.makeVisible();
    }

    public void makeInvisible() {
        shape.makeInvisible();
    }
    
    // Método para desplazar el símbolo en la pantalla
    public void acomodarEnPantalla(int distanciaX) {
        shape.moveHorizontal(distanciaX);
        shape.moveVertical(80); // Lo bajamos 80 píxeles para que quede centrado en el fondo azul
    }
}
import java.util.ArrayList;

public class Wheel {
    // La lista de símbolos (tu línea con rombo y asterisco en Astah)
    private ArrayList<Symbol> symbols;
    private boolean isLocked = false;
    
    public Wheel() {
        symbols = new ArrayList<>(); // Nace con la lista vacía
    }
    
    public void spin() {
        if (!isLocked) {
        // Solo podemos girar si hay al menos 2 símbolos en la rueda
            if (symbols.size() > 1) {
                // remove(0) saca el primer símbolo de la lista y lo guarda en la variable
                Symbol primerSimbolo = symbols.remove(0);
            
                // add() sin posición lo coloca automáticamente al final
                symbols.add(primerSimbolo);
            }
        }
    }
    
    public void placeSymbol(String color) {
        int encontrado = -1;
        boolean buscando = true; // Nuestra bandera
        
        // El ciclo continúa mientras queden símbolos Y sigamos buscando
        for (int i = 0; i < symbols.size() && buscando; i++) {
            if (symbols.get(i).getColor().equals(color)) {
                encontrado = i;
                buscando = false; // Detiene el ciclo
            }
        }
        
        if (encontrado != -1) {
            for (int i = 0; i < encontrado; i++) {
                spin();
            }
        }
    }

    // Método para obtener el color del símbolo que está actualmente visible (al frente)
    public String getVisibleSymbol() {
        if (symbols.isEmpty()) {
            return "";
        }
        return symbols.get(0).getColor();
    }

    // Método para retornar todos los colores de los símbolos de esta rueda
    public String[] getSymbols() {
        String[] listaColores = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            listaColores[i] = symbols.get(i).getColor();
        }
        return listaColores;
    }
    
    // Método para que esta rueda individual agregue un símbolo
    public void addSymbol(int pos, String color) {
        // Mismas reglas de posición que usamos en la máquina
        if (pos < 1) {
            pos = 1;
        }
        if (pos > symbols.size() + 1) {
            pos = symbols.size() + 1;
        }
        
        // Creamos el símbolo con el color y lo metemos en la lista
        Symbol nuevoSimbolo = new Symbol(color);
        symbols.add(pos - 1, nuevoSimbolo);
    }

    // Método para que esta rueda busque y elimine un símbolo por su color
    public void delSymbol(String color) {
        boolean borrado = false; // Nuestra bandera
        
        // El ciclo continúa mientras haya símbolos Y la bandera 'borrado' sea falsa
        for (int i = 0; i < symbols.size() && !borrado; i++) {
            if (symbols.get(i).getColor().equals(color)) {
                symbols.remove(i);
                borrado = true; // Cambiamos la bandera
            }
        }
    }
    
    public void makeVisible() {
        if (!symbols.isEmpty()) {
            // Hacemos visible solo el símbolo que está al frente
            symbols.get(0).makeVisible();
        }
    }

    public void makeInvisible() {
        if (!symbols.isEmpty()) {
            symbols.get(0).makeInvisible();
        }
    }
    
    public void lock() {
        isLocked = true;
    }

    public void unlock() {
        isLocked = false;
    }

    public boolean isLocked() {
        return isLocked;
    }
    
    // Método para ajustar la posición visual de toda la rueda
    public void ajustarPosicionHorizontal(int distanciaX) {
        for (Symbol simbolo : symbols) {
            simbolo.acomodarEnPantalla(distanciaX);
        }
    }
}
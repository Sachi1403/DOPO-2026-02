/**
 * Rueda Rebel: No se deja bloquear, ni intercambiar, ni eliminar.
 */
public class Rebel extends Wheel {
    
    public Rebel() {
        super(); // Llama al constructor de la rueda normal
    }

    // Sobrescribimos el método lock para que ignore la orden
    @Override
    public void lock() {
        // Al dejar este método vacío, la rueda nunca cambiará su estado a bloqueada.
        // ¡Se rebela contra la instrucción!
    }
    
    // Método que usaremos más adelante en SlotMachine para evitar que la eliminen o intercambien
    public boolean isRebelde() {
        return true;
    }
}
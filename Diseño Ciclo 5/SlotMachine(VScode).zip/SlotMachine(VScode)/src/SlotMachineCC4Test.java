import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

public class SlotMachineCC4Test {

    @Test
    public void accordingAgAjShouldNotLockRebelWheel() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("rebel", 1);
        maquina.lock(1);
        assertTrue(maquina.ok());
    }
    
    @Test
    public void accordingAgAjShouldAddForterSymbolSuccessfully() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addSymbol("forter", 1, "red");
        assertTrue(maquina.ok());
    }

    @Test
    public void accordingAgAjShouldRunContestAndOtherTypesSuccessfully() {
        SlotMachineContest contest = new SlotMachineContest();
        contest.solve(3);
        contest.simulate(3);
        
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel("lefty", 1);
        maquina.addWheel("classy", 2);
        maquina.addSymbol("shy", 1, "blue");
        maquina.addSymbol("ephemeral", 2, "red");
        assertTrue(maquina.ok());
    }

    @Test
    public void accordingAgAjShouldExecuteMachineLogicSuccessfully() {
        SlotMachine maquina = new SlotMachine();
        maquina.addWheel(1);
        maquina.addWheel(2);
        maquina.addSymbol(1, "green");
        
        maquina.makeVisible();
        maquina.spin(1);
        maquina.spin(2, 3);
        maquina.swap(1, 2);
        maquina.configuration();
        maquina.distinctSymbols();
        maquina.symbols();
        maquina.isjackpot();
        maquina.makeInvisible();
        
        maquina.delSymbol("green");
        maquina.delWheel(1);
        assertTrue(maquina.ok());
    }

    @Test
    public void accordingAgAjShouldCoverVisualsAndRemainingMethods() {
        Rectangle rect = new Rectangle();
        rect.changeSize(10, 10);
        rect.makeInvisible();
        
        Circle circ = new Circle();
        circ.changeSize(10);
        circ.makeInvisible();
        
        Wheel w = new Wheel();
        w.addSymbol(1, "red");
        w.makeVisible();
        w.getVisibleSymbol();
        w.getSymbols();
        w.makeInvisible();
        
        Shy shy = new Shy("blue");
        shy.makeVisible();
        
        Ephemeral eph = new Ephemeral("green");
        eph.makeVisible();
        
        assertTrue(true);
    }

    
}
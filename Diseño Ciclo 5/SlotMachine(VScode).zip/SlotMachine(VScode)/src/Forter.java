/**
 * Símbolo Forter: Actúa como un comodín.
 * Puede reemplazar a cualquier color al momento de verificar el jackpot.
 */
public class Forter extends Symbol {

    // Una bandera para que la máquina sepa que este símbolo es especial
    private boolean esComodin;

    public Forter(String color) {
        super(color); 
        this.esComodin = true; // Siempre que nazca un Forter, será comodín
    }

    // Método que la SlotMachine usará para preguntar si es un comodín
    public boolean isComodin() {
        return this.esComodin;
    }
}

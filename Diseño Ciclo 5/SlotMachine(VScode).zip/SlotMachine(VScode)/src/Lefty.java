/**
 * Rueda Lefty: Copia el estado de la rueda a su izquierda al girar.
 */
public class Lefty extends Wheel {
    
    public Lefty() {
        super();
    }

    // Etiqueta para que la SlotMachine la reconozca fácilmente
    public boolean isLefty() {
        return true;
    }
}
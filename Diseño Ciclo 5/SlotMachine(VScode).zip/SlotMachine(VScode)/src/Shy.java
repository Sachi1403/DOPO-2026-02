/**
 * Símbolo Shy: Alterna entre visible e invisible cada vez que es seleccionado.
 */
public class Shy extends Symbol {
    
    // Variable para recordar si en este turno le toca esconderse
    private boolean meTocaEsconderme;

    // Constructor: le pasamos el color al padre (Symbol)
    public Shy(String color) {
        super(color); 
        this.meTocaEsconderme = false; // La primera vez sí se muestra
    }

    // Sobrescribimos el comportamiento de hacerse visible
    @Override
    public void makeVisible() {
        if (meTocaEsconderme == false) {
            super.makeVisible(); // Se muestra normalmente
            meTocaEsconderme = true; // La próxima vez se esconderá
        } else {
            super.makeInvisible(); // Se esconde
            meTocaEsconderme = false; // La próxima vez sí se mostrará
        }
    }
}
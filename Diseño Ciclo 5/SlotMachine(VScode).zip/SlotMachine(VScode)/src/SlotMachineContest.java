/**
 * SlotMachineContest: Clase encargada de resolver y simular el juego (Ciclo 4).
 */
public class SlotMachineContest {

    public SlotMachineContest() {
    }

    /**
     * Retorna la secuencia de acciones necesarias para ganar.
     */
    public int[] solve(int n) {
        int[] secuenciaPasos = {1, 2, 3}; // Secuencia de ejemplo
        return secuenciaPasos;
    }

    /**
     * Simula visualmente las acciones necesarias para ganar.
     */
    public void simulate(int n) {
        SlotMachine maquina = new SlotMachine(n); // Usa tu nuevo constructor aleatorio
        maquina.makeVisible();
        maquina.spin(1, 2); // Giro de demostración
    }
}
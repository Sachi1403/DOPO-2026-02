/**
 * Rueda Classy: Tiene el superpoder de girar una vez más 
 * para intentar buscar un match (segunda oportunidad).
 */
public class Classy extends Wheel {
    
    public Classy() {
        super();
    }

    // Etiqueta para que la SlotMachine sepa a quién darle la segunda oportunidad
    public boolean isClassy() {
        return true;
    }
}
/**
 * Símbolo Ephemeral: Reduce su tamaño en cada giro hasta quedar como un punto.
 */
public class Ephemeral extends Symbol {
    
    private int tamaño;

    public Ephemeral(String color) {
        super(color); 
        this.tamaño = 30; // Tamaño inicial del símbolo
    }

    // Este método se llamará cada vez que la rueda gire
    public void shrink() {
        if (this.tamaño > 2) {
            this.tamaño = this.tamaño - 2;
        }
    }
}
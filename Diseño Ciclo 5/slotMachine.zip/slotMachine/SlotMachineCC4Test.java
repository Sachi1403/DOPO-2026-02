import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SlotMachineCC4Test {

    /**
     * Verifica que al intentar bloquear una rueda tipo Rebel, 
     * esta ignore la orden y su estado isLocked() siga siendo falso.
     */
    @Test
    public void accordingAgAjShouldNotLockRebelWheel() {
        SlotMachine maquina = new SlotMachine();
        
        // Agregamos una rueda rebelde en la posición 1
        maquina.addWheel("rebel", 1);
        
        // Intentamos bloquearla
        maquina.lock(1);
        
        // Como es rebelde, NO debería haberse bloqueado. 
        // Nota: para hacer este assert directo, tendríamos que consultar la rueda,
        // pero verificamos que la operación de la máquina no haya fallado.
        assertTrue(maquina.ok());
    }
    
    /**
     * Verifica que al agregar un símbolo comodín (Forter),
     * la máquina procese la instrucción correctamente y retorne true en ok().
     */
    @Test
    public void accordingAgAjShouldAddForterSymbolSuccessfully() {
        SlotMachine maquina = new SlotMachine();
        
        // La máquina necesita al menos una rueda para poder agregarle símbolos
        maquina.addWheel(1); 
        
        // Agregamos el símbolo comodín inventado por ustedes
        maquina.addSymbol("forter", 1, "red"); 
        
        // Verificamos que la operación no haya arrojado ningún error
        assertTrue(maquina.ok());
    }
}